package com.platform.catalog.domain.event;

import com.platform.core.event.DomainEvent;
import lombok.Getter;

@Getter
public class ProductApprovedEvent extends DomainEvent {

    private final String productId;
    private final String vendorId;

    public ProductApprovedEvent(String productId, String vendorId) {
        super();
        this.productId = productId;
        this.vendorId = vendorId;
    }

    @Override
    public String getAggregateId() {
        return productId;
    }

    @Override
    public String getAggregateType() {
        return "Product";
    }
}